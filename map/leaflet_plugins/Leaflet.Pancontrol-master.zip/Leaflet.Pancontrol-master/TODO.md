TODO
====
 - <del>Styling</del>
 - <del>Prevent double-clicking prevent from zooming map</del>
 - <del>Make panning offset configurable</del>
 - Do something about the hardcoded support for the zoom- and zoomslider controls.
 - <del>Make special CSS's for IE.</del>
