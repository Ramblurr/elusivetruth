[Leaflet.Pancontrol](http://kartena.github.com/Leaflet.Pancontrol/)
==================

A panning control for [Leaflet][2]. 

Tested with Chrome, IE 7-9 and Firefox. 

Also see [Leaflet.Zoomslider][1]

### Branches
 - 0.4 — tracks Leaflet 0.4.x and should be stable. 
 - master — tracks Leaflet master and can be considered unstable (but please file bugs!). 

[1]: https://github.com/kartena/Leaflet.zoomslider
[2]: https://github.com/CloudMade/Leaflet